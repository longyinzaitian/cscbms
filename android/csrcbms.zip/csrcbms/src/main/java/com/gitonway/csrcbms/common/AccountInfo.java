package com.gitonway.csrcbms.common;

import java.io.Serializable;

/**
 * Created by zxc94 on 2017/10/17.
 */
public class AccountInfo implements Serializable {
    private String loginUserName;  /*登录账号*/
    private String status;   /*状态*/
    private String realName;   /*姓名*/
    private String idcardNo;   /*身份政*/

    public String getLoginUserName() {
        return loginUserName;
    }

    public void setLoginUserName(String loginUserName) {
        this.loginUserName = loginUserName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getIdcardNo() {
        return idcardNo;
    }

    public void setIdcardNo(String idcardNo) {
        this.idcardNo = idcardNo;
    }
}
