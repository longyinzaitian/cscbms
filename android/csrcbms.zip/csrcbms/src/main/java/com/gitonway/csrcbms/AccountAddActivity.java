package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.gitonway.csrcbms.common.AccountInfo;
import com.gitonway.csrcbms.common.AccountResp;
import com.gitonway.csrcbms.common.GitHubService;

import java.io.Serializable;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AccountAddActivity extends AppCompatActivity {
    EditText edit_name;
    EditText edit_username;
    EditText edit_idcard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_add);
        edit_name= (EditText) findViewById(R.id.edit_name);
        edit_username= (EditText) findViewById(R.id.edit_username);
        edit_idcard= (EditText) findViewById(R.id.edit_idcard);

    }
    public void save(View view){
        Retrofit retrofit5 = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service5 = retrofit5.create(GitHubService.class);
        Call<AccountResp> repos5 = service5.Addaccount(edit_name.getText().toString(),edit_username.getText().toString(),edit_idcard.getText().toString());
        repos5.enqueue(new Callback<AccountResp>() {
            @Override
            public void onResponse(Call<AccountResp> call, Response<AccountResp> response) {
                AccountResp repos= response.body();
                if("true".equals(repos.getSuccess())){
                    Intent intent5=new Intent(AccountAddActivity.this,AccountActivity.class);
                    startActivity(intent5);
                }
            }
            @Override
            public void onFailure(Call<AccountResp> call, Throwable t) {

                t.printStackTrace();
            }
        });
    }
}
