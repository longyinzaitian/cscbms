package com.gitonway.csrcbms.common;

/**
 * Created by zxc94 on 2017/10/12.
 */

public class Fee {
    String id;
    String name;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
