package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.Resp;
import com.gitonway.csrcbms.common.UserResp;

import okhttp3.OkHttpClient;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.List;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class MainActivity extends AppCompatActivity {
    TextView text_login;
    TextView text_register;
    TextView text_nopassword;
    EditText login_name;
    EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text_login= (TextView) findViewById(R.id.text_login);
        text_register= (TextView) findViewById(R.id.text_register);
        text_nopassword= (TextView) findViewById(R.id.text_nopassword);
        login_name= (EditText) findViewById(R.id.login_name);
        password= (EditText) findViewById(R.id.password);
        text_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
/*                MyAsyncTask myAsyncTask=new MyAsyncTask();
                myAsyncTask.doInBackground();*/
              /*  List<Resp> res = null;*/
                 OkHttpClient client = new OkHttpClient.Builder().
                        connectTimeout(60, TimeUnit.SECONDS).
                        readTimeout(60, TimeUnit.SECONDS).
                        writeTimeout(60, TimeUnit.SECONDS).build();
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://192.168.0.106:8080/cscbms/")
                        .client(client)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
                GitHubService service = retrofit.create(GitHubService.class);
                Call<UserResp> repos = service.listRepos(login_name.getText().toString(),password.getText().toString());
                repos.enqueue(new Callback<UserResp>() {
                    @Override
                    public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                        UserResp repos= response.body();

                          if("true".equals(repos.getSuccess())){
                              Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                              intent.putExtra("adminCode",login_name.getText().toString());
                              intent.putExtra("password",password.getText().toString());
                              startActivity(intent);
                          }
                    }
                    @Override
                    public void onFailure(Call<UserResp> call, Throwable t) {

                        t.printStackTrace();
                    }
                });
/*                Intent intent=new Intent(MainActivity.this,HomeActivity.class);
                startActivity(intent);*/

             }
        });
        text_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });
        text_nopassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ForgotActivity.class);
                startActivity(intent);
            }
        });
    }

/*private class MyAsyncTask extends AsyncTask<String,Integer,Userinfo>{
    @Override
    protected Userinfo doInBackground(String... params) {
        Common common=new Common();

        return null;
    }

    @Override
    protected void onPostExecute(Userinfo userinfo) {
        super.onPostExecute(userinfo);
    }
}*/
}
