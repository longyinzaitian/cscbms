package com.gitonway.csrcbms.common;

import java.io.Serializable;

/**
 * Created by zxc94 on 2017/10/16.
 */
public class Modile implements Serializable {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
