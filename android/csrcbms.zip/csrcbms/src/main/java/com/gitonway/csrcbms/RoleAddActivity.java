package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.gitonway.csrcbms.beans.Role;
import com.gitonway.csrcbms.beans.Userinfo;
import com.gitonway.csrcbms.common.RoleInfo;
import com.gitonway.csrcbms.common.UserResp;

import java.util.ArrayList;
import java.util.List;

import static android.widget.LinearLayout.VERTICAL;

public class RoleAddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo_add);
        List<RoleInfo> data=(List<RoleInfo>)getIntent().getSerializableExtra("data");
        RoleAdapter adminAdapter=new RoleAdapter(data,RoleAddActivity.this);
        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adminAdapter);

    }
    public void add(View view){
        Intent intent=new Intent(RoleAddActivity.this,RoleActivity.class);
        startActivity(intent);
    }
}
