package com.gitonway.csrcbms;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.RecyclerSwipeAdapter;
import com.gitonway.csrcbms.beans.Role;
import com.gitonway.csrcbms.common.Modile;
import com.gitonway.csrcbms.common.RoleInfo;


import java.util.List;

/**
 * Created by zxc94 on 2017/10/12.
 */

public class RoleAdapter extends RecyclerSwipeAdapter<RecyclerView.ViewHolder> {
    Context context;
    List<RoleInfo> data;

    public RoleAdapter(List<RoleInfo> data, Context context) {
        this.data = data;
        this.context=context;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.role_recyclerview,parent,false);
        MinViewHolder minViewHolder=new MinViewHolder(view);
        return minViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MinViewHolder main=(MinViewHolder)holder;
        RoleInfo admin=data.get(position);
        main.swipeLayout.setShowMode(SwipeLayout.ShowMode.PullOut);
        main.name_textview.setText(admin.getName());
/*        List<Modile> name=admin.getModiles();
        Modile nn=name.get(position);

        main.right_textview.setText(nn.getName());*/
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getSwipeLayoutResourceId(int position) {
        return position;
    }

    private class MinViewHolder extends RecyclerView.ViewHolder {
        TextView name_textview;
        TextView right_textview;
        SwipeLayout swipeLayout;
        public MinViewHolder(View itemView) {
            super(itemView);
            swipeLayout= (SwipeLayout) itemView.findViewById(R.id.swipelayout);
            name_textview= (TextView) itemView.findViewById(R.id.name_textview);
            right_textview= (TextView) itemView.findViewById(R.id.right_textview);
        }
    }
}
