package com.gitonway.csrcbms;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.gitonway.csrcbms.beans.Account;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/15.
 */

public class BusinessAdapter extends RecyclerView.Adapter {
    Context context;
    List<Account> data;

    public BusinessAdapter(List<Account> data, Context context) {
        this.data = data;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.account_recyclerview, parent, false);
        MinViewHolder minViewHolder = new MinViewHolder(view);
        return minViewHolder;

    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MinViewHolder minViewHolder = (MinViewHolder) holder;
        Account account = data.get(position);
        minViewHolder.name_textview.setText(account.getName());
        minViewHolder.username_textview.setText(account.getUsername());
        minViewHolder.usernmb_textview.setText(account.getUsernmb());
        minViewHolder.state_textview.setText(account.getState());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    private class MinViewHolder extends RecyclerView.ViewHolder {
        TextView username_textview;
        TextView name_textview;
        TextView usernmb_textview;
        TextView state_textview;

        public MinViewHolder(View itemView) {
            super(itemView);
            username_textview = (TextView) itemView.findViewById(R.id.username_textview);
            name_textview = (TextView) itemView.findViewById(R.id.name_textview);
            usernmb_textview = (TextView) itemView.findViewById(R.id.usernmb_textview);
            state_textview = (TextView) itemView.findViewById(R.id.state_textview);
        }
    }
}