package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.gitonway.csrcbms.beans.Account;

import java.util.ArrayList;
import java.util.List;

import static android.widget.LinearLayout.VERTICAL;

public class BusinessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business);
        List<Account> data=new ArrayList<Account>();
        Account admin=new Account();
        admin.setName("zgf");
        admin.setUsername("156");
        admin.setUsernmb("fengnb@163.com");
        admin.setState("开通");
        data.add(admin);

        Account admin1=new Account();
        admin1.setName("zgf");
        admin1.setUsername("156");
        admin1.setUsernmb("fengnb@163.com");
        admin1.setState("开通");
        data.add(admin1);

        BusinessAdapter adminAdapter=new BusinessAdapter(data,BusinessActivity.this);
        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adminAdapter);


    }
    public void add(View view){
        Intent intent=new Intent(BusinessActivity.this,BusinessAddActivity.class);
        startActivity(intent);
    }
}
