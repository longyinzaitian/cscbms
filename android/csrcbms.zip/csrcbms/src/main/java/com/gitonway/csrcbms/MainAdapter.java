package com.gitonway.csrcbms;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.gitonway.csrcbms.beans.Main;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/8.
 */

public class MainAdapter extends RecyclerView.Adapter{
    List<Main> data;
    Context context;
    OnItemClickListener onItemClickListener;
    public  MainAdapter(Context context,List<Main> data){
        this.context=context;
        this.data=data;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=View.inflate(context,R.layout.main_recycler,null);
        MyViewHolder myViewHolder=new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder myViewHolder=(MyViewHolder)holder;
        Main main=data.get(position);
        myViewHolder.image_icon.setImageResource(main.getImageId());
        myViewHolder.text_word.setText(main.getName());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener=onItemClickListener;

    }
    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView text_word;
        ImageView image_icon;
        public MyViewHolder(View itemView) {
            super(itemView);
            text_word= (TextView) itemView.findViewById(R.id.text_word);
            image_icon= (ImageView) itemView.findViewById(R.id.image_icon);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClickListener.onItemClick(v,getAdapterPosition());
                }
            });
        }
    }
    public interface OnItemClickListener {
        void onItemClick( View view, int position);
    }
}
