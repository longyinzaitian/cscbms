package com.gitonway.csrcbms.common;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/17.
 */

public class AccountResp extends Resp {
    private List<AccountInfo> obj;

    public List<AccountInfo> getObj() {
        return obj;
    }

    public void setObj(List<AccountInfo> obj) {
        this.obj = obj;
    }
}
