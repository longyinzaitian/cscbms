package com.gitonway.csrcbms;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.RecyclerSwipeAdapter;
import com.gitonway.csrcbms.beans.Account;
import com.gitonway.csrcbms.beans.Admin;
import com.gitonway.csrcbms.common.AccountInfo;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/15.
 */

public class AccountAdapter extends RecyclerSwipeAdapter<RecyclerView.ViewHolder> {
    Context context;
    List<AccountInfo> data;

    public AccountAdapter(List<AccountInfo> data, Context context) {
        this.data = data;
        this.context=context;
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.account_recyclerview,parent,false);
        MinViewHolder minViewHolder=new MinViewHolder(view);
        return minViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MinViewHolder minViewHolder=(MinViewHolder)holder;
        AccountInfo account=data.get(position);
        minViewHolder.swipeLayout.setShowMode(SwipeLayout.ShowMode.PullOut);
        minViewHolder.name_textview.setText(account.getRealName());
        minViewHolder.username_textview.setText(account.getLoginUserName());
        minViewHolder.usernmb_textview.setText(account.getIdcardNo());
        minViewHolder.state_textview.setText(account.getStatus());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getSwipeLayoutResourceId(int position) {
        return position;
    }

    private class MinViewHolder extends RecyclerView.ViewHolder{
        TextView username_textview;
        TextView name_textview;
        TextView usernmb_textview;
        TextView state_textview;
        SwipeLayout swipeLayout;
        public MinViewHolder(View itemView) {
            super(itemView);
            swipeLayout= (SwipeLayout) itemView.findViewById(R.id.swipelayout);
            username_textview= (TextView) itemView.findViewById(R.id.username_textview);
            name_textview= (TextView) itemView.findViewById(R.id.name_textview);
            usernmb_textview= (TextView) itemView.findViewById(R.id.usernmb_textview);
            state_textview= (TextView) itemView.findViewById(R.id.state_textview);
        }
    }
}
