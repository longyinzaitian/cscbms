package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.gitonway.csrcbms.beans.Admin;
import com.gitonway.csrcbms.beans.Userinfo;
import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.PostageInfo;
import com.gitonway.csrcbms.common.PostageResp;
import com.gitonway.csrcbms.common.RoleResp;
import com.gitonway.csrcbms.common.UserInfo;
import com.gitonway.csrcbms.common.UserResp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.widget.LinearLayout.VERTICAL;

public class AdminActivity extends AppCompatActivity {
    AdminAdapter adminAdapter;
    List<UserInfo> data=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
         data=(List<UserInfo>)getIntent().getSerializableExtra("data");
        /*initData();*/
         adminAdapter=new AdminAdapter(data,AdminActivity.this);
        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adminAdapter);
        adminAdapter.setOnItemClickListener(new AdminAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, final int position) {
                ImageView delete;
                delete= (ImageView) view.findViewById(R.id.delete);
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Retrofit retrofit1 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service1 = retrofit1.create(GitHubService.class);
                        Call<UserResp> repos1 = service1.delereuserinfo(Integer.parseInt(data.get(position).getAdminId()));
                        repos1.enqueue(new Callback<UserResp>() {
                            @Override
                            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                                UserResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    initData();
                                    adminAdapter.notifyDataSetChanged();
                                }
                            }
                            @Override
                            public void onFailure(Call<UserResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });
                    }
                });
            }
        });


    }
    private List<UserInfo> initData(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service = retrofit.create(GitHubService.class);
        Call<UserResp> repos = service.list();
        repos.enqueue(new Callback<UserResp>() {
            @Override
            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                UserResp repos= response.body();
                if("true".equals(repos.getSuccess())){
                     data=repos.getObj();
                }
            }
            @Override
            public void onFailure(Call<UserResp> call, Throwable t) {

                t.printStackTrace();
            }
        });
        return data;
    }
    public void add(View view){
        Intent intent=new Intent(AdminActivity.this,AdminAddActivity.class);
        startActivity(intent);
    }
}
