package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/12.
 */

public class Role {
    private String name;
    private String Right;

    public Role() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRight() {
        return Right;
    }

    public void setRight(String right) {
        Right = right;
    }
}
