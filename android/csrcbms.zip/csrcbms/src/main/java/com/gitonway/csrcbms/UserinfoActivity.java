package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.gitonway.csrcbms.beans.Userinfo;
import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.UserInfo;
import com.gitonway.csrcbms.common.UserResp;

import java.io.Serializable;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UserinfoActivity extends AppCompatActivity {
    EditText edit_name;
    EditText edit_username;
    EditText edit_telephone;
    EditText edit_email;
    List<UserInfo> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);
        edit_name= (EditText) findViewById(R.id.edit_name);
        edit_username= (EditText) findViewById(R.id.edit_username);
        edit_telephone= (EditText) findViewById(R.id.edit_telephone);
        edit_email= (EditText) findViewById(R.id.edit_email);
        data=(List<UserInfo>)getIntent().getSerializableExtra("data");
            edit_name.setText(data.get(0).getName());
            edit_email.setText(data.get(0).getEmail());
            edit_telephone.setText(data.get(0).getTelephone());
            edit_username.setText(data.get(0).getAdminCode());
    }
    public void save(View view){
        Retrofit retrofit8 = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service8 = retrofit8.create(GitHubService.class);
        Call<UserResp> repos8= service8.updateuserinfo(edit_name.getText().toString(),edit_username.getText().toString(),edit_email.getText().toString(),edit_telephone.getText().toString(),data.get(0).getAdminId());
        repos8.enqueue(new Callback<UserResp>() {
            @Override
            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                UserResp repos= response.body();
                if("true".equals(repos.getSuccess())){

                    Intent intent8=new Intent(UserinfoActivity.this,ModifyActivity.class);

                    startActivity(intent8);
                }
            }
            @Override
            public void onFailure(Call<UserResp> call, Throwable t) {

                t.printStackTrace();
            }
        });
    }
}
