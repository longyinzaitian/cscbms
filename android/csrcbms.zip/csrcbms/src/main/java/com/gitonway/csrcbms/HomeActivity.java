package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.gitonway.csrcbms.beans.Main;
import com.gitonway.csrcbms.beans.Role;
import com.gitonway.csrcbms.common.AccountInfo;
import com.gitonway.csrcbms.common.AccountResp;
import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.Modile;
import com.gitonway.csrcbms.common.PostageInfo;
import com.gitonway.csrcbms.common.PostageResp;
import com.gitonway.csrcbms.common.Resp;
import com.gitonway.csrcbms.common.RoleInfo;
import com.gitonway.csrcbms.common.RoleResp;
import com.gitonway.csrcbms.common.UserInfo;
import com.gitonway.csrcbms.common.UserResp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        final List<Main> data=new ArrayList<Main>();
        Main main=new Main();
        main.setImageId(R.drawable.hh);
        main.setName("主页");
        main.setId(1);
        data.add(main);

        Main main1=new Main();
        main1.setImageId(R.drawable.user);
        main1.setName("角色管理");
        main1.setId(2);
        data.add(main1);

        Main main2=new Main();
        main2.setImageId(R.drawable.admin);
        main2.setName("管理员");
        main2.setId(3);
        data.add(main2);

        Main main7=new Main();
        main7.setImageId(R.drawable.zf);
        main7.setName("资费管理");
        main7.setId(4);
        data.add(main7);

        Main main3=new Main();
        main3.setImageId(R.drawable.zwnmb);
        main3.setName("账务账号");
        main3.setId(5);
        data.add(main3);

        Main main4=new Main();
        main4.setImageId(R.drawable.yenmb);
        main4.setName("业务账号");
        main4.setId(6);
        data.add(main4);

        Main main5=new Main();
        main5.setImageId(R.drawable.userinfo);
        main5.setName("个人信息");
        main5.setId(7);
        data.add(main5);

        Main main6=new Main();
        main6.setImageId(R.drawable.password);
        main6.setName("修改密码");
        main6.setId(8);
        data.add(main6);
        final String adminCode=getIntent().getStringExtra("adminCode");
        final String password=getIntent().getStringExtra("password");
        MainAdapter mainAdapter=new MainAdapter(HomeActivity.this,data);
        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.recycclerview);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this,3);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(mainAdapter);
        mainAdapter.setOnItemClickListener(new MainAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (data.get(position).getId()){
                    case 1:break;
                    case 2:
                        Retrofit retrofit1 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service1 = retrofit1.create(GitHubService.class);
                        Call<RoleResp> repos1 = service1.role();
                        repos1.enqueue(new Callback<RoleResp>() {
                            @Override
                            public void onResponse(Call<RoleResp> call, Response<RoleResp> response) {
                                RoleResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<RoleInfo> data=repos.getObj();
                                    Intent intent2=new Intent(HomeActivity.this,RoleAddActivity.class);
                                    intent2.putExtra("data",(Serializable)data);
                                    startActivity(intent2);
                                }
                            }
                            @Override
                            public void onFailure(Call<RoleResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                    case 3:
                        Retrofit retrofit = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service = retrofit.create(GitHubService.class);
                        Call<UserResp> repos = service.list();
                        repos.enqueue(new Callback<UserResp>() {
                            @Override
                            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                                UserResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<UserInfo> data=repos.getObj();
                                    Intent intent3=new Intent(HomeActivity.this,AdminActivity.class);
                                    intent3.putExtra("data",(Serializable)data);
                                    startActivity(intent3);
                                }
                            }
                            @Override
                            public void onFailure(Call<UserResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                    case 4:
                        Retrofit retrofit4 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service4 = retrofit4.create(GitHubService.class);
                        Call<PostageResp> repos4 = service4.Postage();
                        repos4.enqueue(new Callback<PostageResp>() {
                            @Override
                            public void onResponse(Call<PostageResp> call, Response<PostageResp> response) {
                                PostageResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<PostageInfo> data=repos.getObj();
                                    Intent intent4=new Intent(HomeActivity.this,PostageAddActivity.class);
                                    intent4.putExtra("data",(Serializable)data);
                                    startActivity(intent4);
                                }
                            }
                            @Override
                            public void onFailure(Call<PostageResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                    case 5:
                        Retrofit retrofit5 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service5 = retrofit5.create(GitHubService.class);
                        Call<AccountResp> repos5 = service5.account();
                        repos5.enqueue(new Callback<AccountResp>() {
                            @Override
                            public void onResponse(Call<AccountResp> call, Response<AccountResp> response) {
                                AccountResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<AccountInfo> data=repos.getObj();
                                    Intent intent5=new Intent(HomeActivity.this,AccountActivity.class);
                                    intent5.putExtra("data",(Serializable)data);
                                    startActivity(intent5);
                                }
                            }
                            @Override
                            public void onFailure(Call<AccountResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                    case 6:
                        Intent intent6=new Intent(HomeActivity.this,BusinessActivity.class);
                        startActivity(intent6);
                        break;
                    case 7:
                        Retrofit retrofit7 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service7 = retrofit7.create(GitHubService.class);
                        Call<UserResp> repos7= service7.listRepos(adminCode,password);
                        repos7.enqueue(new Callback<UserResp>() {
                            @Override
                            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                                UserResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<UserInfo> data=repos.getObj();
                                    Intent intent7=new Intent(HomeActivity.this,UserinfoActivity.class);
                                    intent7.putExtra("data",(Serializable)data);
                                    startActivity(intent7);
                                }
                            }
                            @Override
                            public void onFailure(Call<UserResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                    case 8:
                        Retrofit retrofit8 = new Retrofit.Builder()
                                .baseUrl("http://192.168.0.106:8080/cscbms/")
                                .addConverterFactory(GsonConverterFactory.create())
                                .build();
                        GitHubService service8 = retrofit8.create(GitHubService.class);
                        Call<UserResp> repos8= service8.listRepos(adminCode,password);
                        repos8.enqueue(new Callback<UserResp>() {
                            @Override
                            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                                UserResp repos= response.body();
                                if("true".equals(repos.getSuccess())){
                                    List<UserInfo> data=repos.getObj();
                                    Intent intent8=new Intent(HomeActivity.this,ModifyActivity.class);

                                    intent8.putExtra("data",(Serializable)data);
                                    startActivity(intent8);
                                }
                            }
                            @Override
                            public void onFailure(Call<UserResp> call, Throwable t) {

                                t.printStackTrace();
                            }
                        });

                        break;
                }
            }
        });
    }
}
