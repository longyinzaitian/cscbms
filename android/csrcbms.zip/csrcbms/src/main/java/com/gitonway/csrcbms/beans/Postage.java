package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/11.
 */
public class Postage {
    private String name;
    private String time;
    private String money;
    private String statuse;

    public Postage(String name, String statuse, String money, String time) {
        this.name = name;
        this.statuse = statuse;
        this.money = money;
        this.time = time;
    }
    public Postage() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getStatuse() {
        return statuse;
    }

    public void setStatuse(String statuse) {
        this.statuse = statuse;
    }
}
