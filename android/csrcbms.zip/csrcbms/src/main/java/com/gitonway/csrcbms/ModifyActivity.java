package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.UserInfo;
import com.gitonway.csrcbms.common.UserResp;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ModifyActivity extends AppCompatActivity {
    EditText edit_username;
    EditText edit_ordpassword;
    EditText edit_password;
    List<UserInfo> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        edit_username= (EditText) findViewById(R.id.edit_username);
        edit_ordpassword= (EditText) findViewById(R.id.edit_ordpassword);
        edit_password= (EditText) findViewById(R.id.edit_password);
         data=(List<UserInfo>)getIntent().getSerializableExtra("data");
        edit_username.setText(data.get(0).getAdminCode());
        edit_ordpassword.setText(data.get(0).getPassword());
    }
    public void save(View view){
        Retrofit retrofit8 = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service8 = retrofit8.create(GitHubService.class);
        Call<UserResp> repos8= service8.modifyPwdjson(edit_password.getText().toString(),data.get(0).getAdminCode());
        repos8.enqueue(new Callback<UserResp>() {
            @Override
            public void onResponse(Call<UserResp> call, Response<UserResp> response) {
                UserResp repos= response.body();
                if("true".equals(repos.getSuccess())){
                    Intent intent8=new Intent(ModifyActivity.this,HomeActivity.class);
                    startActivity(intent8);
                    finish();
                }
            }
            @Override
            public void onFailure(Call<UserResp> call, Throwable t) {

                t.printStackTrace();
            }
        });
    }
}
