package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/8.
 */

public class Main {
    private String name;
    private int imageId;
    private int id;

    public Main(String name, int imageId,int id) {
        this.name = name;
        this.imageId = imageId;
        this.id=id;
    }
    public Main() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
}
