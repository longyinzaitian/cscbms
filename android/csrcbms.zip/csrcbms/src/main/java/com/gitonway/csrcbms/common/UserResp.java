package com.gitonway.csrcbms.common;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/16.
 */

public class UserResp extends Resp {

    private List<UserInfo> obj;

    public List<UserInfo> getObj() {
        return obj;
    }

    public void setObj(List<UserInfo> obj) {
        this.obj = obj;
    }
}
