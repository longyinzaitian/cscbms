package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/12.
 */

public class Userinfo {
    private String name;
    private String password;
    private String number;
    private String eamail;
    private String Right;

    public String getRight() {
        return Right;
    }

    public void setRight(String right) {
        Right = right;
    }

    public Userinfo() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getEamail() {
        return eamail;
    }

    public void setEamail(String eamail) {
        this.eamail = eamail;
    }
}
