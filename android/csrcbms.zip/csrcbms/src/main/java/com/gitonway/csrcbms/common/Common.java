package com.gitonway.csrcbms.common;

import android.util.Log;

import com.gitonway.csrcbms.beans.Userinfo;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by zxc94 on 2017/10/12.
 */

public class Common {
private Userinfo finduser(String name) throws IOException {
    Userinfo userinfo = new Userinfo();
    String urlstr = "";
    Log.e("tag", "loadStocks: "+urlstr );
    URL url = new URL(urlstr);
    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
    httpURLConnection.connect();
if (httpURLConnection.getResponseCode()==200){
    InputStream is = httpURLConnection.getInputStream();
    String result=HttpUtils.readMyInputStream(is);
    Gson gson=new Gson();
    Userinfo user=gson.fromJson(result,Userinfo.class);

}

    return  null;
}
    private  void deleteuser(String name){



    }

}
