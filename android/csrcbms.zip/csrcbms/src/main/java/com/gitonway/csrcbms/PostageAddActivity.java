package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.gitonway.csrcbms.beans.Postage;
import com.gitonway.csrcbms.common.PostageInfo;

import java.util.ArrayList;
import java.util.List;

import static android.widget.LinearLayout.VERTICAL;

public class PostageAddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postage_add);
        List<PostageInfo> data=(List<PostageInfo>)getIntent().getSerializableExtra("data");
        PostageAdapter postageAdapter=new PostageAdapter(data,PostageAddActivity.this);
        RecyclerView recyclerView= (RecyclerView) findViewById(R.id.recyclerview);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(postageAdapter);


    }
    public void add(View view){
        Intent intent=new Intent(PostageAddActivity.this,PostageActivity.class);
        startActivity(intent);
        finish();
    }
}
