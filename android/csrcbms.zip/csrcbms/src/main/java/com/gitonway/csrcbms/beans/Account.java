package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/15.
 */

public class Account {
    private String username;
    private String name;
    private String usernmb;
    private String state;

    public Account() {

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsernmb() {
        return usernmb;
    }

    public void setUsernmb(String usernmb) {
        this.usernmb = usernmb;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
