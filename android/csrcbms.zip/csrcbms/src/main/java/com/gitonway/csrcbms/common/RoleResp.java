package com.gitonway.csrcbms.common;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/16.
 */

public class RoleResp extends Resp {

    private List<RoleInfo> obj;

    public List<RoleInfo> getObj() {
        return obj;
    }

    public void setObj(List<RoleInfo> obj) {
        this.obj = obj;
    }
}
