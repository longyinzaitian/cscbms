package com.gitonway.csrcbms.beans;

/**
 * Created by zxc94 on 2017/10/10.
 */

public class Admin {
    private String name;
    private String nmb;
    private String email;

    public Admin(String name, String email, String nmb) {
        this.name = name;
        this.email = email;
        this.nmb = nmb;
    }
    public Admin() {

    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNmb() {
        return nmb;
    }

    public void setNmb(String nmb) {
        this.nmb = nmb;
    }
}
