package com.gitonway.csrcbms.common;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * Created by Administrator on 2017/10/13.
 */

public interface GitHubService {
    @FormUrlEncoded
    @POST("open/finduserinfo.do")
    Call<UserResp> listRepos(@Field("adminCode") String user, @Field("password") String pwd);

    @GET("open/finduserinfo.do")
    Call<UserResp> list();

    @FormUrlEncoded
    @POST("open/adduserinfo.do")
    Call<UserResp> Adduserinfo(@Field("adminCode") String user, @Field("password") String pwd,@Field("name") String name,@Field("email")String email,@Field("telephone")String telephone);

    @FormUrlEncoded
    @POST("open/deleteuserinfo.do")
    Call<UserResp> delereuserinfo(@Field("id")int id);

    @FormUrlEncoded
    @POST("open/updateuserinfo.do")
    Call<UserResp> updateuserinfo(@Field("adminCode") String user, @Field("name") String name,@Field("email")String email,@Field("telephone")String telephone,@Field("adminId")String adminId);

    @FormUrlEncoded
    @POST("open/modifyPwdjson.do")
    Call<UserResp> modifyPwdjson(@Field("password") String password,@Field("adminCode")String adminCode);

    @GET("open/getAllRoles.do")
    Call<RoleResp> role();

    @FormUrlEncoded
    @POST("open/adduserinfo.do")
    Call<Resp> register(@Field("adminCode") String user, @Field("password") String pwd,@Field("telephone") String tp,@Field("email") String email);

    @GET("open/findByCost.do")
    Call<PostageResp> Postage();


    @FormUrlEncoded
    @POST("open/addCost.do")
    Call<Resp> AddPostage(@FieldMap Map<String,String> params);

    @GET("open/findByAccount.do")
    Call<AccountResp> account();

    @FormUrlEncoded
    @POST("open/addAccount.do")
    Call<AccountResp> Addaccount(@Field("loginUserName") String username,@Field("realName")String realName,@Field("idcardNo")String  idcardNo);
}