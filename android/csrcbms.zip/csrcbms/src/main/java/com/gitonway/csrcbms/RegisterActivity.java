package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.Resp;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.gitonway.csrcbms.R.id.login_name;

public class RegisterActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    EditText telephone;
    EditText email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username= (EditText) findViewById(R.id.username);
        password= (EditText) findViewById(R.id.password);
        telephone= (EditText) findViewById(R.id.telephone);
        email= (EditText) findViewById(R.id.email);

    }

    public void register(View view){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service = retrofit.create(GitHubService.class);
        Call<Resp> repos = service.register(username.getText().toString(),password.getText().toString(),telephone.getText().toString(),email.getText().toString());
        repos.enqueue(new Callback<Resp>() {
            @Override
            public void onResponse(Call<Resp> call, Response<Resp> response) {
                Resp repos= response.body();

                if("true".equals(repos.getSuccess())){
                    Intent intent=new Intent(RegisterActivity.this,MainActivity.class);
                    startActivity(intent);
                }
                if("false".equals(repos.getSuccess())){
                    Intent intent=new Intent(RegisterActivity.this,RegisterActivity.class);
                    Toast.makeText(RegisterActivity.this, "注册失败！", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                }
            }
            @Override
            public void onFailure(Call<Resp> call, Throwable t) {

                t.printStackTrace();
            }
        });

    }
}
