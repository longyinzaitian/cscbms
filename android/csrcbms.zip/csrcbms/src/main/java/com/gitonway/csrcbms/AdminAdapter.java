package com.gitonway.csrcbms;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.daimajia.swipe.SwipeLayout;
import com.daimajia.swipe.adapters.RecyclerSwipeAdapter;
import com.gitonway.csrcbms.common.UserInfo;


import java.util.List;


/**
 * Created by zxc94 on 2017/10/10.
 */

public class AdminAdapter extends RecyclerSwipeAdapter<RecyclerView.ViewHolder> {
    Context context;
    List<UserInfo> data;
    OnItemClickListener onItemClickListener;
    public AdminAdapter(List<UserInfo> data,Context context) {
        this.data = data;
        this.context=context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.admin_recyclerview,parent,false);
        MinViewHolder minViewHolder=new MinViewHolder(view);
        return minViewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MinViewHolder main=(MinViewHolder)holder;
        UserInfo admin=data.get(position);
        main.swipeLayout.setShowMode(SwipeLayout.ShowMode.PullOut);
        main.name_textview.setText(admin.getName());
        main.nmb_textview.setText(admin.getTelephone());
        main.email_textview.setText(admin.getEmail());
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {

        this.onItemClickListener=onItemClickListener;

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getSwipeLayoutResourceId(int position) {
        return position;
    }

    private class MinViewHolder extends RecyclerView.ViewHolder{
        TextView name_textview;
        TextView nmb_textview;
        TextView email_textview;
        SwipeLayout swipeLayout;
        public MinViewHolder(View itemView) {
            super(itemView);
            swipeLayout= (SwipeLayout) itemView.findViewById(R.id.swipelayout);
            name_textview= (TextView) itemView.findViewById(R.id.name_textview);
            nmb_textview= (TextView) itemView.findViewById(R.id.nmb_textview);
            email_textview= (TextView) itemView.findViewById(R.id.email_textview);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onItemClickListener.onItemClick(v,getAdapterPosition());
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick( View view, int position);
    }
}
