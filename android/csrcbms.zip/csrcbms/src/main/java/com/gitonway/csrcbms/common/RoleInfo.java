package com.gitonway.csrcbms.common;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zxc94 on 2017/10/16.
 */
public class RoleInfo implements Serializable {
    private String name;
    private List<Modile> modiles;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List getModiles() {
        return modiles;
    }

    public void setModiles(List modiles) {
        this.modiles = modiles;
    }
}
