package com.gitonway.csrcbms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.gitonway.csrcbms.common.GitHubService;
import com.gitonway.csrcbms.common.PostageInfo;
import com.gitonway.csrcbms.common.PostageResp;
import com.gitonway.csrcbms.common.Resp;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PostageActivity extends AppCompatActivity {
    EditText text_name;
    EditText text_baseCost;
    EditText text_baseDuration;
    EditText text_unitCost;
    EditText text_descr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postage);
        text_name= (EditText) findViewById(R.id.text_name);
        text_baseCost= (EditText) findViewById(R.id.text_baseCost);
        text_baseDuration= (EditText) findViewById(R.id.text_baseDuration);
        text_unitCost= (EditText) findViewById(R.id.text_unitCost);
        text_descr= (EditText) findViewById(R.id.text_descr);


    }
    public void save(View view){
        Retrofit retrofit4 = new Retrofit.Builder()
                .baseUrl("http://192.168.0.106:8080/cscbms/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        GitHubService service4 = retrofit4.create(GitHubService.class);
        Map<String,String> data=new HashMap<>();
        data.put("name",text_name.getText().toString());
        data.put("baseDuration",text_baseCost.getText().toString());
        data.put("baseCost",text_baseCost.getText().toString());
        data.put("unitCost",text_unitCost.getText().toString());
        data.put("descr",text_descr.getText().toString());
        Call<Resp> repos4 = service4.AddPostage(data);
        repos4.enqueue(new Callback<Resp>() {
            @Override
            public void onResponse(Call<Resp> call, Response<Resp> response) {
                Resp repos= response.body();
                if("true".equals(repos.getSuccess())){
                    Intent intent4=new Intent(PostageActivity.this,PostageAddActivity.class);
                    startActivity(intent4);
                    Toast.makeText(PostageActivity.this, "添加资费成功", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<Resp> call, Throwable t) {

                t.printStackTrace();
            }
        });

    }
}
