package com.gitonway.csrcbms.common;

import java.util.List;

/**
 * Created by zxc94 on 2017/10/17.
 */
public class PostageResp extends Resp {
    private  List<PostageInfo> obj;

    public List<PostageInfo> getObj() {
        return obj;
    }

    public void setObj(List<PostageInfo> obj) {
        this.obj = obj;
    }
}
