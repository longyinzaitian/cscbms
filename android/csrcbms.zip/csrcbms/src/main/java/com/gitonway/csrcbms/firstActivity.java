package com.gitonway.csrcbms;

import android.content.Intent;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.os.Handler;
public class firstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        RelativeLayout relativeLayout= (RelativeLayout) findViewById(R.id.activity_first);
         handler.sendMessageDelayed(handler.obtainMessage(1), 3000);

    }
    Handler handler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what==1){
                Intent intent=new Intent(firstActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
            return true;
        }
    });
}
